'use client';

const InsightCard = () => (
  <div>
    Insight Card
  </div>
);

export default InsightCard;
